import React from "react";

const About = () => {
  return (
    <div className="p-10 text-center">
      <h1 className="text-3xl font-bold">About Us</h1>
      <p className="mt-4 text-gray-600">
        We use AI to analyze fruit ripeness and help users determine the best time to consume their fruits.
      </p>
    </div>
  );
};

export default About;
