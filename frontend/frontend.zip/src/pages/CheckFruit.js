import React, { useState } from "react";

const CheckFruit = () => {
  const [image, setImage] = useState(null);
  const [result, setResult] = useState(null);
  const [loading, setLoading] = useState(false);

  const handleImageUpload = (event) => {
    const file = event.target.files[0];
    if (file) {
      setImage(URL.createObjectURL(file));
      sendToBackend(file);
    }
  };

  const sendToBackend = async (file) => {
    const formData = new FormData();
    formData.append("file", file);
    setLoading(true);
    setResult(null);

    try {
      const response = await fetch("http://localhost:8000/predict", {
        method: "POST",
        body: formData,
      });

      const data = await response.json();
      setResult(data);

      // ✅ Save to database if prediction is successful
      if (data.fruit) {
        const token = localStorage.getItem("token"); // Retrieve token

        const saveResponse = await fetch("http://localhost:5000/api/fruit/save", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`,
          },
          body: JSON.stringify({
            name: data.fruit.split(" ")[0] || "Unknown",
            ripeness: data.fruit.split(" ")[1] || "Unknown",
            confidence: data.confidence,
            checkedOn: new Date().toISOString(),
          }),
        });

        if (!saveResponse.ok) {
          throw new Error("Failed to save fruit data");
        }
      }
    } catch (error) {
      console.error("Error:", error);
      setResult({ error: "Failed to analyze image" });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex flex-col items-center p-8">
      <h1 className="text-4xl font-bold mb-6">Check Fruit Ripeness 🍏</h1>
      <input type="file" accept="image/*" onChange={handleImageUpload} className="mb-4" />
      {image && <img src={image} alt="Selected" className="w-40 h-40 object-cover rounded shadow" />}
      {loading && <p>Analyzing...</p>}
      {result && !result.error && (
        <div className="p-4 mt-4 bg-white rounded shadow-md">
          <h2 className="text-xl font-semibold">Result:</h2>
          <p><strong>{result.fruit?.split(" ")[0] || "Unknown"}</strong></p>
          <p>Ripeness: <strong>{result.fruit?.split(" ")[1] || "Unknown"}</strong></p>
          <p>Confidence: <strong>{result.confidence ? `${result.confidence}%` : "N/A"}</strong></p>
        </div>
      )}
      {result?.error && <p className="text-red-500">{result.error}</p>}
    </div>
  );
};

export default CheckFruit;
